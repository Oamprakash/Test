<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function index() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->User_model->get_user($username, $password);

        if ($user) {
            $response = array('status' => 'success', 'message' => 'Login successful', 'data' => $user);
        } else {
            $response = array('status' => 'error', 'message' => 'Invalid username or password');
        }

        header('Content-Type: application/json');
        echo json_encode($response);
    }
}
?>
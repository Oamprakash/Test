<?php
include '/application/config/config.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $response = array('status' => 'success', 'message' => 'Login successful');
} else {
    $response = array('status' => 'error', 'message' => 'Invalid username or password');
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
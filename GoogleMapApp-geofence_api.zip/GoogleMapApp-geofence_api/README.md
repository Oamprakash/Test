# GoogleMapApp
a sample app that use google map and geofence API.

## Screenshot

<img src ="https://github.com/SaqibAhmed-hub/GoogleMapApp/blob/geofence_api/app/src/main/java/com/example/mapapp/img/1679899941476.JPEG" width=180 height =400>      <img src ="https://github.com/SaqibAhmed-hub/GoogleMapApp/blob/geofence_api/app/src/main/java/com/example/mapapp/img/1679899935988.JPEG" width=180 height =400>




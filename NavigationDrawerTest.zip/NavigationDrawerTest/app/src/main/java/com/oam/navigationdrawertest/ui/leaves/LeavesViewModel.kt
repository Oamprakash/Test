package com.oam.navigationdrawertest.ui.leaves

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class leavesViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is leaves Fragment"
    }
    val text: LiveData<String> = _text
}